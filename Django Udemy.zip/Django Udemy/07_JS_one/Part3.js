var weight=prompt("weight in pounds(lb)?")

alert("you weight in kg is"+weight* 0.454)
console.log('conversion complete')
