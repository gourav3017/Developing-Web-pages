var firstName=prompt("what is your first name");
var lastName=prompt("what is your last name");
var age=prompt("what is your age");
var height= prompt("what is your height");
var weight= prompt("what is your weight");
var pet=prompt("what is your pet name");
if (firstName[0]===lastName[0] && age >20 && age <30 && height =>170 && pet[pet.length-1]=='y'){
  console.log("hey there")
}

else{
  console.log("Sorry nothing for you")
}
