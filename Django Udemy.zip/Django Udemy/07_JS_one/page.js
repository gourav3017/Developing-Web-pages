alert("Welcome all")
var deposit=prompt("how much?")
alert("you have"+deposit)
console.log(deposit)
